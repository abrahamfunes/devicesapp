<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model as BaseModel;

class ModelsType extends BaseModel
{
    protected $table = 'models_types';

    public $timestamps = false;

}
